"""
run_statistics.py
===================
Statistical analysis of Stage 1-3 results: paired t-tests, Wilcoxon
signed-rank tests, bootstrap 95% confidence intervals, and Cohen's d effect
sizes for the pairwise method comparisons that matter most for the paper's
claims (e.g. "NLM significantly outperforms wavelet thresholding",
"CLAHE significantly outperforms global histogram equalization").

Requires: scipy, numpy

Usage:
    python run_statistics.py --stage1 ./results/stage1_results.json \
                              --stage2 ./results/stage2_enhancement_results.json \
                              --stage3 ./results/stage3_edges_results.json \
                              --out ./results/statistics_report.json
"""
import argparse
import json
import numpy as np
from scipy import stats


def cohens_d_paired(a, b):
    """Cohen's d for paired samples, using the standard deviation of the
    differences (the appropriate denominator for paired designs)."""
    diff = np.array(a) - np.array(b)
    return float(np.mean(diff) / np.std(diff, ddof=1))


def bootstrap_ci_mean_diff(a, b, n_boot=10000, ci=95, seed=42):
    """Bootstrap confidence interval for the mean of paired differences."""
    rng = np.random.default_rng(seed)
    diff = np.array(a) - np.array(b)
    n = len(diff)
    boot_means = np.empty(n_boot)
    for i in range(n_boot):
        sample = rng.choice(diff, size=n, replace=True)
        boot_means[i] = sample.mean()
    lower = np.percentile(boot_means, (100 - ci) / 2)
    upper = np.percentile(boot_means, 100 - (100 - ci) / 2)
    return float(lower), float(upper)


def paired_comparison(name_a, a, name_b, b, metric_name):
    """Runs paired t-test, Wilcoxon signed-rank, Cohen's d, and a bootstrap CI
    on the mean difference (a - b), for two equal-length paired samples
    (i.e. matched per-image measurements from the same set of images)."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    assert len(a) == len(b), "Paired comparison requires equal-length, aligned samples"

    diff = a - b
    t_stat, t_p = stats.ttest_rel(a, b)
    try:
        w_stat, w_p = stats.wilcoxon(a, b)
    except ValueError:
        # Wilcoxon fails if all differences are exactly zero; report as such
        w_stat, w_p = float("nan"), float("nan")

    d = cohens_d_paired(a, b)
    ci_lo, ci_hi = bootstrap_ci_mean_diff(a, b)

    return {
        "comparison": f"{name_a} vs {name_b}",
        "metric": metric_name,
        "n_pairs": int(len(a)),
        "mean_a": float(np.mean(a)),
        "mean_b": float(np.mean(b)),
        "mean_difference": float(np.mean(diff)),
        "bootstrap_95ci_mean_diff": [ci_lo, ci_hi],
        "paired_t_test": {"t_statistic": float(t_stat), "p_value": float(t_p)},
        "wilcoxon_signed_rank": {"statistic": float(w_stat), "p_value": float(w_p)},
        "cohens_d": d,
        "effect_size_interpretation": interpret_cohens_d(d),
        "significant_at_0.05": bool(t_p < 0.05 and (np.isnan(w_p) or w_p < 0.05)),
    }


def interpret_cohens_d(d):
    ad = abs(d)
    if ad < 0.2:
        return "negligible"
    elif ad < 0.5:
        return "small"
    elif ad < 0.8:
        return "medium"
    else:
        return "large"


def get_per_image_metric(records, method_key, method_val, sigma, metric_key, image_key="image"):
    """Extracts metric values aligned by image, for one (method, sigma)
    combination, sorted by image name so two extracted series for the same
    sigma are guaranteed to be in matching order for paired tests."""
    filtered = [r for r in records if r[method_key] == method_val and r["sigma"] == sigma]
    filtered.sort(key=lambda r: r[image_key])
    images = [r[image_key] for r in filtered]
    values = [r[metric_key] for r in filtered]
    return images, values


def aligned_pair(records, method_key, val_a, val_b, sigma, metric_key):
    """Returns two value lists for val_a and val_b, aligned by image name,
    keeping only images present in both (should be all of them if both
    methods ran on the full corpus)."""
    imgs_a, vals_a = get_per_image_metric(records, method_key, val_a, sigma, metric_key)
    imgs_b, vals_b = get_per_image_metric(records, method_key, val_b, sigma, metric_key)
    map_a = dict(zip(imgs_a, vals_a))
    map_b = dict(zip(imgs_b, vals_b))
    common = sorted(set(map_a) & set(map_b))
    if len(common) < len(imgs_a):
        print(f"  [note] {val_a} vs {val_b} at sigma={sigma}: "
              f"{len(imgs_a)} vs {len(imgs_b)} images, using {len(common)} common images")
    return [map_a[k] for k in common], [map_b[k] for k in common]


def run_stage1_stats(stage1_records):
    """Key comparisons for the denoising stage: best method (NLM) vs each
    classical alternative, and BM3D vs NLM if BM3D results are present."""
    report = []
    sigmas = sorted(set(r["sigma"] for r in stage1_records))
    methods_present = sorted(set(r["method"] for r in stage1_records))

    comparisons = []
    if "nlm" in methods_present:
        for m in methods_present:
            if m != "nlm":
                comparisons.append(("nlm", m))
    if "bm3d" in methods_present and "nlm" in methods_present:
        comparisons.append(("bm3d", "nlm"))

    for metric in ["psnr", "ssim"]:
        for sigma in sigmas:
            for a, b in comparisons:
                vals_a, vals_b = aligned_pair(stage1_records, "method", a, b, sigma, metric)
                if len(vals_a) < 2:
                    continue
                result = paired_comparison(a, vals_a, b, vals_b, f"{metric}_sigma{sigma}")
                report.append(result)
    return report


def run_stage2_stats(stage2_records):
    report = []
    sigmas = sorted(set(r["sigma"] for r in stage2_records))
    comparisons = [("clahe", "hist_eq"), ("clahe", "none_baseline"), ("clahe", "gamma")]
    for metric in ["rms_contrast", "ssim_vs_clean"]:
        for sigma in sigmas:
            for a, b in comparisons:
                vals_a, vals_b = aligned_pair(stage2_records, "method", a, b, sigma, metric)
                if len(vals_a) < 2:
                    continue
                report.append(paired_comparison(a, vals_a, b, vals_b, f"{metric}_sigma{sigma}"))
    return report


def run_stage3_stats(stage3_records):
    report = []
    sigmas = sorted(set(r["sigma"] for r in stage3_records))
    comparisons = [("clahe", "hist_eq"), ("clahe", "denoised_only")]
    for sigma in sigmas:
        for a, b in comparisons:
            vals_a, vals_b = aligned_pair(stage3_records, "variant", a, b, sigma, "edge_f1_vs_clean")
            if len(vals_a) < 2:
                continue
            report.append(paired_comparison(a, vals_a, b, vals_b, f"edge_f1_sigma{sigma}"))
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage1", default=None, help="Path to stage1 denoising results JSON")
    ap.add_argument("--stage2", default=None, help="Path to stage2 enhancement results JSON")
    ap.add_argument("--stage3", default=None, help="Path to stage3 edge results JSON")
    ap.add_argument("--out", default="./results/statistics_report.json")
    args = ap.parse_args()

    full_report = {}

    if args.stage1:
        with open(args.stage1) as f:
            s1 = json.load(f)
        print(f"Stage 1: {len(s1)} records, running paired significance tests ...")
        full_report["stage1_denoising"] = run_stage1_stats(s1)

    if args.stage2:
        with open(args.stage2) as f:
            s2 = json.load(f)
        print(f"Stage 2: {len(s2)} records, running paired significance tests ...")
        full_report["stage2_enhancement"] = run_stage2_stats(s2)

    if args.stage3:
        with open(args.stage3) as f:
            s3 = json.load(f)
        print(f"Stage 3: {len(s3)} records, running paired significance tests ...")
        full_report["stage3_edges"] = run_stage3_stats(s3)

    with open(args.out, "w") as f:
        json.dump(full_report, f, indent=2)

    print(f"\nStatistics report written to {args.out}")
    print("\n--- Summary of key comparisons ---")
    for stage_name, comparisons in full_report.items():
        print(f"\n{stage_name}:")
        for c in comparisons:
            sig = "***" if c["significant_at_0.05"] else "ns"
            print(f"  {c['comparison']:30s} [{c['metric']:15s}] "
                  f"diff={c['mean_difference']:+.4f}  "
                  f"95%CI=[{c['bootstrap_95ci_mean_diff'][0]:+.4f}, {c['bootstrap_95ci_mean_diff'][1]:+.4f}]  "
                  f"p={c['paired_t_test']['p_value']:.2e}  "
                  f"d={c['cohens_d']:+.3f} ({c['effect_size_interpretation']})  {sig}")


if __name__ == "__main__":
    main()
