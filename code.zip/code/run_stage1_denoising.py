"""
run_stage1_denoising.py
========================
Stage 1: Denoising benchmark across six methods (Gaussian, median, bilateral,
non-local means, wavelet BayesShrink, BM3D) on the full real image corpus,
at three Gaussian noise levels (sigma = 0.05, 0.10, 0.15).

Designed to use ALL available CPU cores via multiprocessing.Pool, with
checkpointing so a long run (e.g. BM3D on 10,000 images) survives interruption.

Usage:
    python run_stage1_denoising.py --corpus ./data/corpus_gray --out ./results \
                                    --workers 0   # 0 = use all logical cores

Each image is processed independently (embarrassingly parallel), so wall-clock
scales close to linearly with core count for the classical methods. BM3D is
by far the most expensive method (typically 1-15s per image depending on
resolution and CPU), so budget accordingly: on an 8-core machine, 10,000
images x 3 sigma levels x ~3s/image / 8 cores ~ 3.1 hours for BM3D alone.
Use --methods to run a subset (e.g. skip bm3d first, add it later).
"""
import argparse
import os
import glob
import json
import time
import hashlib
import multiprocessing as mp
from functools import partial

import numpy as np
import cv2
from PIL import Image
from skimage import img_as_float
from skimage.util import random_noise
from skimage.restoration import denoise_nl_means, denoise_wavelet, estimate_sigma
from skimage.metrics import peak_signal_noise_ratio as psnr, structural_similarity as ssim

from PIL import PngImagePlugin
PngImagePlugin.MAX_TEXT_CHUNK = 100 * 1024 * 1024  # allow large ICC profiles

ALL_METHODS = ["gaussian_blur", "median", "bilateral", "nlm", "wavelet_bayes", "bm3d"]
NOISE_LEVELS = [0.05, 0.10, 0.15]


def stable_seed(name):
    """Deterministic seed from filename (Python's hash() is process-randomized
    by default and MUST NOT be used here, or noise realizations would differ
    across the run / across resumed checkpoints)."""
    return int(hashlib.md5(name.encode()).hexdigest(), 16) % (2**32)


def load_gray(path):
    img = Image.open(path).convert("L")
    return img_as_float(np.array(img))


def denoise_gaussian(noisy, sigma):
    blur_sigma = max(0.8, sigma * 12)
    ksize = int(2 * round(3 * blur_sigma) + 1)
    return cv2.GaussianBlur(noisy.astype(np.float32), (ksize, ksize), blur_sigma)


def denoise_median(noisy):
    return cv2.medianBlur((noisy * 255).astype(np.uint8), 5).astype(np.float64) / 255.0


def denoise_bilateral(noisy):
    out = cv2.bilateralFilter((noisy * 255).astype(np.uint8), d=9, sigmaColor=75, sigmaSpace=75)
    return out.astype(np.float64) / 255.0


def denoise_nlm(noisy, sigma_est):
    return denoise_nl_means(noisy, h=1.15 * sigma_est, fast_mode=True, patch_size=5, patch_distance=6)


def denoise_wavelet_bayes(noisy):
    return denoise_wavelet(noisy, method="BayesShrink", mode="soft", rescale_sigma=True)


def denoise_bm3d(noisy, sigma):
    import bm3d  # imported lazily so other methods work even if bm3d isn't installed
    return bm3d.bm3d(noisy, sigma_psd=sigma)


def process_one_image(fpath, methods):
    """Runs all requested methods at all noise levels for one image.
    Returns a list of result dicts. Designed to be called inside a worker
    process via multiprocessing.Pool.map."""
    fname = os.path.basename(fpath)
    clean = load_gray(fpath)
    rng = np.random.default_rng(stable_seed(fname))

    out = []
    for sigma in NOISE_LEVELS:
        noisy = random_noise(clean, mode="gaussian", var=sigma ** 2, rng=rng)
        sigma_est = estimate_sigma(noisy, channel_axis=None)
        noisy_clipped = np.clip(noisy, 0, 1)
        noisy_psnr = psnr(clean, noisy_clipped, data_range=1.0)
        noisy_ssim = ssim(clean, noisy_clipped, data_range=1.0)

        for method in methods:
            t0 = time.perf_counter()
            if method == "gaussian_blur":
                den = denoise_gaussian(noisy, sigma)
            elif method == "median":
                den = denoise_median(noisy)
            elif method == "bilateral":
                den = denoise_bilateral(noisy)
            elif method == "nlm":
                den = denoise_nlm(noisy, sigma_est)
            elif method == "wavelet_bayes":
                den = denoise_wavelet_bayes(noisy)
            elif method == "bm3d":
                den = denoise_bm3d(noisy, sigma)
            else:
                raise ValueError(f"Unknown method: {method}")
            elapsed = time.perf_counter() - t0

            den = np.clip(den, 0, 1)
            out.append({
                "image": fname, "sigma": sigma, "method": method,
                "psnr": float(psnr(clean, den, data_range=1.0)),
                "ssim": float(ssim(clean, den, data_range=1.0)),
                "noisy_psnr": float(noisy_psnr), "noisy_ssim": float(noisy_ssim),
                "time_sec": float(elapsed),
            })
    return out


def load_checkpoint(path):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"completed_files": [], "results": []}


def save_checkpoint(path, state):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True, help="Folder of grayscale PNGs (from build_corpus.py)")
    ap.add_argument("--out", default="./results", help="Output directory for results/checkpoints")
    ap.add_argument("--methods", default=",".join(ALL_METHODS),
                     help="Comma-separated list of methods to run, e.g. 'gaussian_blur,median,bm3d'")
    ap.add_argument("--workers", type=int, default=0, help="Number of worker processes (0 = all logical cores)")
    ap.add_argument("--limit", type=int, default=None, help="Cap number of images (default: all in corpus)")
    ap.add_argument("--checkpoint-every", type=int, default=20,
                     help="Save a checkpoint every N completed images")
    ap.add_argument("--tag", default="stage1",
                     help="Tag used in output filenames, e.g. 'stage1_bm3d' for a BM3D-only run")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    methods = args.methods.split(",")
    n_workers = args.workers if args.workers > 0 else mp.cpu_count()

    files = sorted(glob.glob(os.path.join(args.corpus, "*.png")))
    if args.limit:
        files = files[: args.limit]

    checkpoint_path = os.path.join(args.out, f"{args.tag}_checkpoint.json")
    result_path = os.path.join(args.out, f"{args.tag}_results.json")

    state = load_checkpoint(checkpoint_path)
    completed = set(state["completed_files"])
    results = state["results"]

    pending = [f for f in files if f not in completed]
    print(f"Corpus: {len(files)} images | Already done: {len(completed)} | Remaining: {len(pending)}")
    print(f"Methods: {methods}")
    print(f"Workers: {n_workers} (detected {mp.cpu_count()} logical cores)")

    if not pending:
        print("Nothing to do — all images already completed.")
        with open(result_path, "w") as f:
            json.dump(results, f, indent=2)
        return

    worker_fn = partial(process_one_image, methods=methods)
    t_start = time.perf_counter()
    n_done_this_run = 0

    with mp.Pool(processes=n_workers) as pool:
        for fpath, res in zip(pending, pool.imap(worker_fn, pending, chunksize=1)):
            results.extend(res)
            completed.add(fpath)
            n_done_this_run += 1

            if n_done_this_run % args.checkpoint_every == 0:
                elapsed = time.perf_counter() - t_start
                rate = n_done_this_run / elapsed
                remaining = len(pending) - n_done_this_run
                eta_sec = remaining / rate if rate > 0 else float("inf")
                print(f"[{len(completed)}/{len(files)}] "
                      f"{n_done_this_run} done this run, "
                      f"{rate:.2f} img/s, ETA {eta_sec/60:.1f} min")
                save_checkpoint(checkpoint_path, {"completed_files": list(completed), "results": results})

    save_checkpoint(checkpoint_path, {"completed_files": list(completed), "results": results})
    with open(result_path, "w") as f:
        json.dump(results, f, indent=2)

    total_elapsed = time.perf_counter() - t_start
    print(f"\nDone. Processed {n_done_this_run} images in {total_elapsed:.1f}s "
          f"({n_done_this_run/total_elapsed:.2f} img/s with {n_workers} workers).")
    print(f"Total images completed (all time): {len(completed)}/{len(files)}")
    print(f"Final results: {result_path}")


if __name__ == "__main__":
    main()
