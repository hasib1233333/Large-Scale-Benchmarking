"""
run_stage4_scalability.py
============================
Stage 4: Throughput / scalability benchmark on the REAL corpus (no synthetic
images), run at multiple corpus sizes and multiple worker counts, to produce
a genuine multicore speedup curve -- this directly answers the reviewer
concern that the original single-core scalability result was hardware-specific.

For each corpus size in --sizes, runs the fixed 3-stage pipeline
(Gaussian denoise -> CLAHE enhance -> Canny edges) both sequentially and with
multiprocessing.Pool at each worker count in --worker-counts, and reports
wall-clock time, throughput, and speedup relative to the sequential baseline.

Usage:
    python run_stage4_scalability.py --corpus ./data/corpus_gray \
        --sizes 500,1000,2500,5000,10000 --worker-counts 1,2,4,8 --out ./results
"""
import argparse
import os
import glob
import json
import time
import multiprocessing as mp

import numpy as np
import cv2
from PIL import Image
from skimage import img_as_float
from skimage.exposure import equalize_adapthist
from skimage.feature import canny


def load_gray(path):
    img = Image.open(path).convert("L")
    return img_as_float(np.array(img))


def process_one(path):
    img = load_gray(path)
    t0 = time.perf_counter()
    den = cv2.GaussianBlur(img.astype(np.float32), (5, 5), 1.0)
    t1 = time.perf_counter()
    enh = equalize_adapthist(np.clip(den, 0, 1), clip_limit=0.01, kernel_size=16)
    t2 = time.perf_counter()
    edges = canny(enh, sigma=1.5)
    t3 = time.perf_counter()
    return {"denoise": t1 - t0, "enhance": t2 - t1, "edges": t3 - t2, "total": t3 - t0}


def run_sequential(paths):
    t0 = time.perf_counter()
    stage_times = {"denoise": 0.0, "enhance": 0.0, "edges": 0.0}
    for p in paths:
        r = process_one(p)
        for k in stage_times:
            stage_times[k] += r[k]
    return time.perf_counter() - t0, stage_times


def run_parallel(paths, n_workers):
    t0 = time.perf_counter()
    with mp.Pool(n_workers) as pool:
        results = pool.map(process_one, paths, chunksize=max(1, len(paths) // (n_workers * 4)))
    wall = time.perf_counter() - t0
    stage_times = {k: sum(r[k] for r in results) for k in ("denoise", "enhance", "edges")}
    return wall, stage_times


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", default="./results")
    ap.add_argument("--sizes", default="500,1000,2500,5000,10000")
    ap.add_argument("--worker-counts", default=None,
                     help="Comma-separated, default: 1,2,4,N where N = all logical cores")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    n_cpus = mp.cpu_count()
    sizes = [int(s) for s in args.sizes.split(",")]

    if args.worker_counts:
        worker_counts = sorted(set(int(w) for w in args.worker_counts.split(",")))
    else:
        worker_counts = sorted(set([1, 2, 4, n_cpus]))

    print(f"Detected {n_cpus} logical CPUs. Testing worker counts: {worker_counts}")

    all_files = sorted(glob.glob(os.path.join(args.corpus, "*.png")))
    max_size = max(sizes)
    if len(all_files) < max_size:
        print(f"WARNING: corpus has only {len(all_files)} images, requested max size {max_size}. "
              f"Will cycle (repeat) the real images to reach the requested size, "
              f"and this repetition will be reported explicitly in the results JSON.")
    # Build a (possibly cycled) file list of length max_size, real images repeated if needed
    cycled = [all_files[i % len(all_files)] for i in range(max_size)]

    results = []
    for size in sizes:
        subset = cycled[:size]
        is_repeated = size > len(all_files)

        seq_wall, seq_stages = run_sequential(subset)
        seq_throughput = size / seq_wall
        print(f"[size={size}] sequential: {seq_wall:.2f}s, {seq_throughput:.1f} img/s")

        worker_results = {}
        for nw in worker_counts:
            par_wall, par_stages = run_parallel(subset, nw)
            par_throughput = size / par_wall
            speedup = seq_wall / par_wall
            print(f"[size={size}] workers={nw}: {par_wall:.2f}s, {par_throughput:.1f} img/s, "
                  f"speedup={speedup:.2f}x")
            worker_results[str(nw)] = {
                "wall_sec": par_wall, "throughput_imgs_per_sec": par_throughput,
                "speedup_vs_sequential": speedup, "stage_breakdown_sec": par_stages,
            }

        results.append({
            "corpus_size": size,
            "distinct_real_images_available": len(all_files),
            "images_repeated_to_reach_size": is_repeated,
            "logical_cpus_detected": n_cpus,
            "sequential_wall_sec": seq_wall,
            "sequential_throughput_imgs_per_sec": seq_throughput,
            "sequential_stage_breakdown_sec": seq_stages,
            "pool_results_by_worker_count": worker_results,
        })

    out_path = os.path.join(args.out, "stage4_scalability_results.json")
    with open(out_path, "w") as f:
        json.dump({
            "logical_cpus_detected": n_cpus,
            "distinct_real_images_available": len(all_files),
            "worker_counts_tested": worker_counts,
            "results": results,
        }, f, indent=2)
    print(f"\nDone. Results written to {out_path}")


if __name__ == "__main__":
    main()
