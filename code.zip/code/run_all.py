"""
run_all.py
===========
Master script that runs the entire pipeline end to end, in the recommended
order. Each stage is resumable (checkpointed), so if your machine needs to
be restarted partway through, just rerun this script -- completed work is
not redone.

Recommended usage on a fresh machine:

    pip install -r requirements.txt
    python run_all.py --workers 0          # 0 = auto-detect all logical cores

This will, in order:
  1. Download ImageNetV2-MatchedFrequency (10,000 real images, ~1.26GB)
  2. Build the flat grayscale working corpus (resized, max dim 512px)
  3. Run Stage 1: denoising benchmark, fast classical methods (5 methods)
  4. Run Stage 1: BM3D (run separately -- this is the slow part)
  5. Run Stage 2: enhancement benchmark
  6. Run Stage 3: edge-detection consistency benchmark
  7. Run Stage 4: multicore scalability benchmark (real images, no synthetic)
  8. Run statistical analysis (paired t-test, Wilcoxon, CIs, effect sizes)

You can also run each stage individually -- see the corresponding script's
--help for options. This is recommended for BM3D specifically, since it is
by far the slowest stage and you may want to run it overnight separately.

Estimated time on an 8-core modern CPU, full 10,000-image corpus:
  - Download + corpus build:      ~10-20 minutes (network dependent)
  - Stage 1 (5 fast methods):     ~15-30 minutes
  - Stage 1 (BM3D):               ~3-6 HOURS  <-- by far the bottleneck
  - Stage 2 (enhancement):        ~20-40 minutes
  - Stage 3 (edge detection):     ~20-40 minutes
  - Stage 4 (scalability):        ~10-20 minutes
  - Statistics:                   <1 minute

If you don't need the full 10,000 for every stage, use --limit to cap the
corpus size for faster iteration while testing (e.g. --limit 200), then
rerun without --limit for the final paper numbers.
"""
import argparse
import subprocess
import sys
import os
import multiprocessing as mp


def run(cmd):
    print(f"\n{'='*70}\n$ {' '.join(cmd)}\n{'='*70}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"\n[ERROR] Command failed with exit code {result.returncode}: {' '.join(cmd)}")
        sys.exit(result.returncode)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="./data")
    ap.add_argument("--results-dir", default="./results")
    ap.add_argument("--workers", type=int, default=0, help="0 = auto-detect all logical cores")
    ap.add_argument("--limit", type=int, default=None, help="Cap corpus size (for quick testing)")
    ap.add_argument("--skip-download", action="store_true", help="Skip dataset download (already done)")
    ap.add_argument("--skip-bm3d", action="store_true",
                     help="Skip BM3D (run it separately later -- it is the slow stage)")
    ap.add_argument("--scalability-sizes", default="500,1000,2500,5000,10000")
    args = ap.parse_args()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    corpus_raw = os.path.join(args.data_dir, "imagenetv2")
    corpus_gray = os.path.join(args.data_dir, "corpus_gray")
    n_workers = args.workers if args.workers > 0 else mp.cpu_count()

    print(f"Detected {mp.cpu_count()} logical CPU cores. Using --workers {n_workers}.")

    if not args.skip_download:
        run([sys.executable, os.path.join(script_dir, "download_dataset.py"), "--out", corpus_raw])

    extracted = os.path.join(corpus_raw, "imagenetv2-matched-frequency-format-val")
    build_cmd = [sys.executable, os.path.join(script_dir, "build_corpus.py"),
                 "--src", extracted, "--out", corpus_gray, "--max-dim", "512"]
    if args.limit:
        build_cmd += ["--limit", str(args.limit)]
    run(build_cmd)

    fast_methods = "gaussian_blur,median,bilateral,nlm,wavelet_bayes"
    s1_cmd = [sys.executable, os.path.join(script_dir, "run_stage1_denoising.py"),
              "--corpus", corpus_gray, "--out", args.results_dir,
              "--methods", fast_methods, "--workers", str(n_workers), "--tag", "stage1"]
    run(s1_cmd)

    if not args.skip_bm3d:
        bm3d_cmd = [sys.executable, os.path.join(script_dir, "run_stage1_denoising.py"),
                    "--corpus", corpus_gray, "--out", args.results_dir,
                    "--methods", "bm3d", "--workers", str(n_workers), "--tag", "stage1_bm3d"]
        run(bm3d_cmd)
    else:
        print("\n[skipped] BM3D -- run later with:\n"
              f"  python run_stage1_denoising.py --corpus {corpus_gray} --out {args.results_dir} "
              f"--methods bm3d --workers {n_workers} --tag stage1_bm3d")

    run([sys.executable, os.path.join(script_dir, "run_stage2_enhancement.py"),
         "--corpus", corpus_gray, "--out", args.results_dir, "--workers", str(n_workers)])

    run([sys.executable, os.path.join(script_dir, "run_stage3_edges.py"),
         "--corpus", corpus_gray, "--out", args.results_dir, "--workers", str(n_workers)])

    run([sys.executable, os.path.join(script_dir, "run_stage4_scalability.py"),
         "--corpus", corpus_gray, "--out", args.results_dir,
         "--sizes", args.scalability_sizes])

    stats_cmd = [sys.executable, os.path.join(script_dir, "run_statistics.py"),
                 "--stage1", os.path.join(args.results_dir, "stage1_results.json"),
                 "--stage2", os.path.join(args.results_dir, "stage2_enhancement_results.json"),
                 "--stage3", os.path.join(args.results_dir, "stage3_edges_results.json"),
                 "--out", os.path.join(args.results_dir, "statistics_report.json")]
    run(stats_cmd)

    if not args.skip_bm3d:
        bm3d_results = os.path.join(args.results_dir, "stage1_bm3d_results.json")
        print(f"\n[note] BM3D results are in a separate file: {bm3d_results}\n"
              f"       Merge with stage1_results.json (same schema) before final analysis, e.g.:\n"
              f"       python -c \"import json; a=json.load(open('{os.path.join(args.results_dir,'stage1_results.json')}'));"
              f" b=json.load(open('{bm3d_results}')); json.dump(a+b, open('{os.path.join(args.results_dir,'stage1_all_results.json')}','w'))\"")

    print("\n\nAll stages complete. Results are in:", args.results_dir)


if __name__ == "__main__":
    main()
