"""
download_dataset.py
====================
Downloads the ImageNetV2 "MatchedFrequency" test set (Recht et al., ICML 2019):
https://huggingface.co/datasets/vaishaal/ImageNetV2

This is a real, peer-reviewed, citable benchmark of exactly 10,000 photographic
images (1000 ImageNet classes x 10 images each), released openly with NO
Hugging Face login / license click-through required (unlike ImageNet-1k itself).

Usage:
    pip install huggingface_hub tqdm --upgrade
    python download_dataset.py --out ./data/imagenetv2

Output:
    ./data/imagenetv2/imagenetv2-matched-frequency-format-val/<class_id>/*.jpeg
    (10,000 .jpeg files total, organized in 1000 class subfolders)

If huggingface_hub download fails for any reason, the script falls back to a
plain HTTPS request against the resolved Hugging Face file URL.
"""
import argparse
import os
import sys
import tarfile
import urllib.request

HF_REPO = "vaishaal/ImageNetV2"
HF_FILENAME = "imagenetv2-matched-frequency.tar.gz"
HF_DIRECT_URL = f"https://huggingface.co/datasets/{HF_REPO}/resolve/main/{HF_FILENAME}"


def download_via_hf_hub(out_dir):
    from huggingface_hub import hf_hub_download
    print(f"Downloading {HF_FILENAME} from {HF_REPO} via huggingface_hub ...")
    path = hf_hub_download(repo_id=HF_REPO, filename=HF_FILENAME,
                            repo_type="dataset", local_dir=out_dir)
    return path


def download_via_requests(out_dir):
    import requests
    print(f"Downloading {HF_FILENAME} via direct HTTPS request ...")
    dest = os.path.join(out_dir, HF_FILENAME)
    with requests.get(HF_DIRECT_URL, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        downloaded = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                f.write(chunk)
                downloaded += len(chunk)
                if total:
                    pct = 100 * downloaded / total
                    print(f"\r  {downloaded/1e6:.0f} MB / {total/1e6:.0f} MB ({pct:.1f}%)", end="")
        print()
    return dest


def download_via_urllib(out_dir):
    print(f"Downloading {HF_FILENAME} via urllib (last-resort fallback) ...")
    dest = os.path.join(out_dir, HF_FILENAME)
    urllib.request.urlretrieve(HF_DIRECT_URL, dest)
    return dest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="./data/imagenetv2", help="Output directory")
    ap.add_argument("--keep-archive", action="store_true",
                     help="Keep the .tar.gz after extraction (default: delete it)")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)

    archive_path = None
    errors = []
    for fn in (download_via_hf_hub, download_via_requests, download_via_urllib):
        try:
            archive_path = fn(args.out)
            break
        except Exception as e:
            errors.append(f"{fn.__name__}: {e}")
            print(f"  [failed] {fn.__name__}: {e}")

    if archive_path is None:
        print("\nAll download methods failed:")
        for e in errors:
            print(" -", e)
        print(f"\nManual fallback: open this URL in a browser and save the file,")
        print(f"then place it at {os.path.join(args.out, HF_FILENAME)} and rerun with --skip-download:")
        print(f"  {HF_DIRECT_URL}")
        sys.exit(1)

    print(f"\nDownloaded to: {archive_path}")
    print("Extracting ...")
    with tarfile.open(archive_path) as tf:
        tf.extractall(args.out)

    if not args.keep_archive:
        os.remove(archive_path)
        print("Removed archive (use --keep-archive to retain it).")

    # Verify count
    extracted_root = os.path.join(args.out, "imagenetv2-matched-frequency-format-val")
    n_images = 0
    for root, _, files in os.walk(extracted_root):
        n_images += sum(1 for f in files if f.lower().endswith((".jpeg", ".jpg", ".png")))

    print(f"\nDone. Found {n_images} images under {extracted_root}")
    if n_images != 10000:
        print(f"WARNING: expected 10,000 images, found {n_images}. "
              f"Check the extraction output above for errors.")
    else:
        print("Verified: exactly 10,000 images, as expected for ImageNetV2-MatchedFrequency.")


if __name__ == "__main__":
    main()
