"""
run_stage3_edges.py
=====================
Stage 3: Canny edge-detection consistency benchmark. Compares edge maps from
(a) denoised-only, (b) global histogram equalization, (c) CLAHE, against the
clean image's own edge map, on the full corpus. Multicore via
multiprocessing.Pool.

Usage:
    python run_stage3_edges.py --corpus ./data/corpus_gray --out ./results
"""
import argparse
import os
import glob
import json
import time
import hashlib
import multiprocessing as mp

import numpy as np
from PIL import Image, PngImagePlugin
PngImagePlugin.MAX_TEXT_CHUNK = 100 * 1024 * 1024
from skimage import img_as_float
from skimage.util import random_noise
from skimage.restoration import denoise_nl_means, estimate_sigma
from skimage.exposure import equalize_hist, equalize_adapthist
from skimage.feature import canny

NOISE_LEVELS = [0.05, 0.10, 0.15]


def stable_seed(name):
    return int(hashlib.md5(name.encode()).hexdigest(), 16) % (2**32)


def load_gray(path):
    img = Image.open(path).convert("L")
    return img_as_float(np.array(img))


def edge_f1(pred_edges, ref_edges):
    tp = np.logical_and(pred_edges, ref_edges).sum()
    fp = np.logical_and(pred_edges, ~ref_edges).sum()
    fn = np.logical_and(~pred_edges, ref_edges).sum()
    precision = tp / (tp + fp + 1e-9)
    recall = tp / (tp + fn + 1e-9)
    f1 = 2 * precision * recall / (precision + recall + 1e-9)
    return float(f1), float(precision), float(recall)


def process_one_image(fpath):
    fname = os.path.basename(fpath)
    clean = load_gray(fpath)
    clean_edges = canny(clean, sigma=1.5)
    clean_density = float(clean_edges.mean())
    rng = np.random.default_rng(stable_seed(fname))

    out = []
    for sigma in NOISE_LEVELS:
        noisy = random_noise(clean, mode="gaussian", var=sigma ** 2, rng=rng)
        sigma_est = estimate_sigma(noisy, channel_axis=None)
        denoised = np.clip(
            denoise_nl_means(noisy, h=1.15 * sigma_est, fast_mode=True, patch_size=5, patch_distance=6), 0, 1
        )

        variants = {
            "denoised_only": denoised,
            "hist_eq": np.clip(equalize_hist(denoised), 0, 1),
            "clahe": np.clip(equalize_adapthist(denoised, clip_limit=0.01, kernel_size=32), 0, 1),
        }

        for variant_name, img in variants.items():
            edges = canny(img, sigma=1.5)
            f1, prec, rec = edge_f1(edges, clean_edges)
            out.append({
                "image": fname, "sigma": sigma, "variant": variant_name,
                "edge_f1_vs_clean": f1, "edge_precision": prec, "edge_recall": rec,
                "edge_density": float(edges.mean()), "clean_edge_density": clean_density,
            })
    return out


def load_checkpoint(path):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"completed_files": [], "results": []}


def save_checkpoint(path, state):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", default="./results")
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--checkpoint-every", type=int, default=50)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    n_workers = args.workers if args.workers > 0 else mp.cpu_count()

    files = sorted(glob.glob(os.path.join(args.corpus, "*.png")))
    if args.limit:
        files = files[: args.limit]

    checkpoint_path = os.path.join(args.out, "stage3_checkpoint.json")
    result_path = os.path.join(args.out, "stage3_edges_results.json")

    state = load_checkpoint(checkpoint_path)
    completed = set(state["completed_files"])
    results = state["results"]
    pending = [f for f in files if f not in completed]

    print(f"Corpus: {len(files)} | Done: {len(completed)} | Remaining: {len(pending)} | Workers: {n_workers}")
    if not pending:
        with open(result_path, "w") as f:
            json.dump(results, f, indent=2)
        print("Nothing to do.")
        return

    t_start = time.perf_counter()
    n_done = 0
    with mp.Pool(processes=n_workers) as pool:
        for fpath, res in zip(pending, pool.imap(process_one_image, pending, chunksize=1)):
            results.extend(res)
            completed.add(fpath)
            n_done += 1
            if n_done % args.checkpoint_every == 0:
                elapsed = time.perf_counter() - t_start
                print(f"[{len(completed)}/{len(files)}] {n_done/elapsed:.2f} img/s")
                save_checkpoint(checkpoint_path, {"completed_files": list(completed), "results": results})

    save_checkpoint(checkpoint_path, {"completed_files": list(completed), "results": results})
    with open(result_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nDone. {len(completed)}/{len(files)} images completed. Results: {result_path}")


if __name__ == "__main__":
    main()
