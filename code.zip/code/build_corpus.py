"""
build_corpus.py
================
Converts the downloaded ImageNetV2 images into a flat grayscale working set
for the denoising/enhancement/edge-detection pipeline, with a reproducible
manifest (filename -> original class folder) for citation/methods reporting.

Usage:
    python build_corpus.py --src ./data/imagenetv2/imagenetv2-matched-frequency-format-val \
                            --out ./data/corpus_gray --max-dim 512 --limit 10000
"""
import argparse
import os
import json
import glob
from PIL import Image
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="Path to extracted ImageNetV2 folder")
    ap.add_argument("--out", default="./data/corpus_gray", help="Output flat folder")
    ap.add_argument("--max-dim", type=int, default=512,
                     help="Resize so the longer side does not exceed this many pixels")
    ap.add_argument("--limit", type=int, default=None,
                     help="Cap total number of images processed (default: all)")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)

    files = sorted(glob.glob(os.path.join(args.src, "**", "*.jpeg"), recursive=True))
    files += sorted(glob.glob(os.path.join(args.src, "**", "*.jpg"), recursive=True))
    if args.limit:
        files = files[: args.limit]

    manifest = []
    n_ok, n_fail = 0, 0
    for i, fpath in enumerate(files):
        try:
            class_id = os.path.basename(os.path.dirname(fpath))
            img = Image.open(fpath).convert("L")
            w, h = img.size
            if max(w, h) > args.max_dim:
                scale = args.max_dim / max(w, h)
                img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

            out_name = f"inv2_{i:05d}.png"
            out_path = os.path.join(args.out, out_name)
            img.save(out_path)

            manifest.append({"file": out_name, "source": "ImageNetV2-MatchedFrequency",
                              "class_id": class_id, "orig_size": [w, h]})
            n_ok += 1
        except Exception as e:
            n_fail += 1
            print(f"  [skip] {fpath}: {e}")

        if (i + 1) % 1000 == 0:
            print(f"Processed {i+1}/{len(files)} ...")

    with open(os.path.join(args.out, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"\nDone. {n_ok} images written to {args.out}, {n_fail} failed/skipped.")
    print(f"Manifest written to {os.path.join(args.out, 'manifest.json')}")


if __name__ == "__main__":
    main()
