"""
run_coco_pipeline.py
====================
Runs the full pipeline on MS-COCO train2017 dataset.
Fully checkpointed — if interrupted, rerun the same command and it
continues from where it left off. No data is lost.

Usage:
    python run_coco_pipeline.py
"""
import subprocess
import sys
import os

COCO_SRC = r"C:\Users\Md Hasibuzzaman\Downloads\train2017\train2017"
CORPUS   = "./data/corpus_coco"
RESULTS  = "./results_coco"
WORKERS  = "0"
METHODS  = "gaussian_blur,median,bilateral,nlm,wavelet_bayes"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable


def run(cmd, label=""):
    tag = f"  [{label}]" if label else ""
    print(f"\n{'='*60}\n{tag} $ {' '.join(cmd)}\n{'='*60}", flush=True)
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"\n[ERROR] Step failed (exit {result.returncode}). Fix the error and rerun — completed work is checkpointed.")
        sys.exit(result.returncode)


def script(name):
    return os.path.join(SCRIPT_DIR, name)


os.makedirs(RESULTS, exist_ok=True)

# Stage 0 — Build grayscale corpus from COCO (skip if already built)
import glob
existing = glob.glob(os.path.join(CORPUS, "*.png"))
if len(existing) == 0:
    run([PY, script("build_corpus.py"),
         "--src", COCO_SRC,
         "--out", CORPUS],
        label="Corpus build")
else:
    print(f"\n[Corpus build] Skipped — {len(existing)} PNGs already in {CORPUS}")

# Stage 1 — Denoising (5 fast methods, checkpointed per image)
run([PY, script("run_stage1_denoising.py"),
     "--corpus", CORPUS,
     "--out",    RESULTS,
     "--methods", METHODS,
     "--workers", WORKERS,
     "--tag",    "stage1"],
    label="Stage 1 denoising")

# Stage 2 — Enhancement benchmark
run([PY, script("run_stage2_enhancement.py"),
     "--corpus", CORPUS,
     "--out",    RESULTS,
     "--workers", WORKERS],
    label="Stage 2 enhancement")

# Stage 3 — Edge detection
run([PY, script("run_stage3_edges.py"),
     "--corpus", CORPUS,
     "--out",    RESULTS,
     "--workers", WORKERS],
    label="Stage 3 edges")

# Stage 4 — Scalability
run([PY, script("run_stage4_scalability.py"),
     "--corpus", CORPUS,
     "--out",    RESULTS],
    label="Stage 4 scalability")

# Statistics
run([PY, script("run_statistics.py"),
     "--stage1", os.path.join(RESULTS, "stage1_results.json"),
     "--stage2", os.path.join(RESULTS, "stage2_enhancement_results.json"),
     "--stage3", os.path.join(RESULTS, "stage3_edges_results.json"),
     "--out",    os.path.join(RESULTS, "statistics_report.json")],
    label="Statistics")

print(f"\n\nAll stages complete. Results saved to: {RESULTS}")
